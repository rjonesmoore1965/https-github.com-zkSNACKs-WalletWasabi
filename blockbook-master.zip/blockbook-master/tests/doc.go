// Package tests provides functions for loading and running integration tests
package tests
