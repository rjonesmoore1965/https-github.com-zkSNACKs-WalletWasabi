//go:build integration

package tests

import (
	"testing"
)

func TestIntegration(t *testing.T) {
	runIntegrationTests(t)
}
